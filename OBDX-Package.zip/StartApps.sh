cd /scratch/gsh/oracle/wlserver/server/bin
.  ./setWLSEnv.sh
java weblogic.WLST /StartApps.py

