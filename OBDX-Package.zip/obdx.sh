#su - gsh

cd /
wget https://objectstorage.us-ashburn-1.oraclecloud.com/p/qBt0IF_C8xsBQkUHDt84yJYTQtejodxm9VbmIWYtKq2527dkwaDIdZAmf0Uaza1P/n/id3kyspkytmr/b/bucket_banco_conceito/o/OBDX201.tar.gz
tar -xvf OBDX201.tar.gz

cd /scratch/gsh/OBDX

wget https://objectstorage.us-ashburn-1.oraclecloud.com/p/n7bWnNDx4335X-xjinor9d6Drgp23burHDQGyGLZBBFFwJpmcLYuwaVqsI8AelH3/n/id3kyspkytmr/b/bucket_banco_conceito/o/lib.tar.gz
